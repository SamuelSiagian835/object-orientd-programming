package pbo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import pbo.model.Student;
import pbo.model.Course;

import java.util.List;
import java.util.Scanner;

public class App {
    private static EntityManagerFactory factory;
    private static EntityManager entityManager;

    public static void main(String[] args) {
        factory = Persistence.createEntityManagerFactory("StudentPU");
        entityManager = factory.createEntityManager();

        String command;
        Scanner scanner = new Scanner(System.in);

        while (true) {
            command = scanner.nextLine();
            String[] split = command.split("#");

            if (command.equals("---")) {
                cleanTables();
                cleanTables1();
                break;
            } else if (split[0].equals("student-add")) {
                if (split.length < 4) {
                    System.out.println("Invalid command format!");
                    continue;
                }

                String nim = split[1];
                String nama = split[2];
                String prodi = split[3];

                // Periksa apakah mahasiswa dengan nim yang sama sudah ada
                Student existingStudent = entityManager.find(Student.class, nim);
                if (existingStudent != null) {

                    continue;
                }

                Student student = new Student(nim, nama, prodi);

                try {
                    entityManager.getTransaction().begin();
                    entityManager.persist(student);
                    entityManager.flush();
                    entityManager.getTransaction().commit();
                } catch (Exception e) {
                    entityManager.getTransaction().rollback();
                    System.out.println("Failed to add student: " + e.getMessage());
                }
            } else if (split[0].equals("student-show-all")) {
                entityManager.getTransaction().begin();
                TypedQuery<Student> query = entityManager.createQuery("SELECT s FROM Student s ORDER BY s.nim ASC", Student.class);
                List<Student> students = query.getResultList();
                entityManager.getTransaction().commit();

                if (students.isEmpty()) {
                    System.out.println("No students found.");
                } else {
                    for (Student student : students) {
                        System.out.println(student.getNim() + "|" + student.getNama() + "|" + student.getProdi());
                    }
                }
            } else if (split[0].equals("course-add")) {
              if (split.length < 5) {
                  System.out.println("Invalid command format!");
                  continue;
              }
          
              String kode = split[1];
              String nama = split[2];
              int semester = Integer.parseInt(split[3]);
              int kredit = Integer.parseInt(split[4]);
          
              // Periksa apakah mata kuliah dengan kode yang sama sudah ada
              Course existingCourse = entityManager.find(Course.class, kode);
              if (existingCourse != null) {

                  continue;
              }
          
              Course course = new Course(kode, nama, semester, kredit);
          
              try {
                  entityManager.getTransaction().begin();
                  entityManager.persist(course);
                  entityManager.flush();
                  entityManager.getTransaction().commit();
              } catch (Exception e) {
                  entityManager.getTransaction().rollback();
                  System.out.println("Failed to add course: " + e.getMessage());
              }
          }
           else if (split[0].equals("course-show-all")) {
                entityManager.getTransaction().begin();
                TypedQuery<Course> query = entityManager.createQuery("SELECT c FROM Course c ORDER BY c.semester ASC, c.kode ASC", Course.class);
                List<Course> courses = query.getResultList();
                entityManager.getTransaction().commit();

                if (courses.isEmpty()) {
                    System.out.println("No courses found.");
                } else {
                    for (Course course : courses) {
                        System.out.println(course.getKode() + "|" + course.getNama() + "|" + course.getSemester() + "|" + course.getKredit());
                    }
                }
            }
        }

        entityManager.close();
        factory.close();
    }

    private static void cleanTables() {
        try {
            entityManager.getTransaction().begin();

            // Hapus data dari tabel Student
            entityManager.createQuery("DELETE FROM Student").executeUpdate();
            

            // Tambahkan pembersihan untuk tabel lain di sini (jika ada)

            entityManager.getTransaction().commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
        }
    }
    private static void cleanTables1() {
      try {
          entityManager.getTransaction().begin();

          // Hapus data dari tabel Student
          entityManager.createQuery("DELETE FROM Course").executeUpdate();
          

          // Tambahkan pembersihan untuk tabel lain di sini (jika ada)

          entityManager.getTransaction().commit();
      } catch (Exception e) {
          entityManager.getTransaction().rollback();
      }
  }
    
}
